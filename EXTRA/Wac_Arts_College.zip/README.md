# WAC Google Chrome Extension
## Google Chrome Extension for Wac Arts College

A Google Chrome extension which provides useful links for students of Wac Arts College.

Links to their google docs, email, classroom, calendar (opens in tabs?) and also links to the website and social media?
